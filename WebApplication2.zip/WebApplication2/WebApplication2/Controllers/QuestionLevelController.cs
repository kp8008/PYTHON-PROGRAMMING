﻿using System.Reflection.Emit;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class QuestionlevelController : Controller
    {
        public IActionResult QuestionLevelList()
        {
            return View();
        }
        public IActionResult AddQuestionLevel()
        {
            return View();
        }
    }
}
