﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class QuizWiseQuestionController : Controller
    {
        public IActionResult QuizWiseQuestion()
        {
            return View();
        }
        public IActionResult QuizWiseQuestionDetails()
        {
            return View();
        }
        public IActionResult AddQuizWiseQuestionDetails()
        {
            return View();
        }


    }
}
