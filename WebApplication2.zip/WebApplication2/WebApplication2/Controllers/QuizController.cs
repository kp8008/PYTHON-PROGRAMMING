﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class QuizController : Controller
    {
        public IActionResult QuizList()
        {
            return View();
        }
        public IActionResult AddQuiz()
        {
            return View();
        }
    }
}
