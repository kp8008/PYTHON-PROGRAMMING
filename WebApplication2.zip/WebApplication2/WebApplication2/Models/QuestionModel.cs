﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class QuestionModel
    {
        [Required(ErrorMessage ="please enter Question first")]
        public string Question { get; set; }

        [Required(ErrorMessage = "please enter Question A ")]
        public string OpationA { get; set; }
        [Required(ErrorMessage = "please enter Question B")]
        public string OpationB { get; set; }
        [Required(ErrorMessage = "please enter Question C")]
        public string OpationC { get; set; }
        [Required(ErrorMessage = "please enter Question D")]
        public string OpationD { get; set; }
        [Required(ErrorMessage = "please enter answer first")]
        public string Answer { get; set; }
        [Required(ErrorMessage = "please enter marks")]
        public string Marks { get; set; }
    }
}
