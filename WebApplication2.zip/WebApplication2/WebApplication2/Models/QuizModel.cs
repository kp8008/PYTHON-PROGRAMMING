﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class QuizModel
    {
        [Required(ErrorMessage ="please enter Quiz name first")]
        
        public string QuizName { get; set; }

        [Required(ErrorMessage ="please enter total question")]
        public string TotalQuetion { get; set; }



        [Required(ErrorMessage = "please enter quiz date first")]
        public string QuizDate { get; set; }
    }
}
