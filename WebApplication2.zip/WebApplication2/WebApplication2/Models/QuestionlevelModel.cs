﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class QuestionlevelModel
    {
        [Required(ErrorMessage ="please enter question level")]
        public string Questionlevel { get; set; }
    }
}
